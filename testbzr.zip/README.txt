Changed text file.
